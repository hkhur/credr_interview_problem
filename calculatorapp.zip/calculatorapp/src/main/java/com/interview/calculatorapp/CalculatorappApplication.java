package com.interview.calculatorapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorappApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculatorappApplication.class, args);
	}

}
