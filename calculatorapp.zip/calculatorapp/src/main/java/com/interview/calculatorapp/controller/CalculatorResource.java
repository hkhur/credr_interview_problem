package com.interview.calculatorapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.interview.calculatorapp.exceptionhandler.CustomizedException;
import com.interview.calculatorapp.service.CalculatorService;

@RestController
@RequestMapping(value = "/api")
public class CalculatorResource {

	@Autowired CalculatorService calculatorService;
	
	@GetMapping(value = "/addition/{firstNumber}/{secondNumber}")
	public int performAddition(@PathVariable int firstNumber, @PathVariable int secondNumber)
	{
		return calculatorService.performAddition(firstNumber,secondNumber);
	}

	@GetMapping(value = "/subtraction/{firstNumber}/{secondNumber}")
	public int performSubtraction(@PathVariable Integer firstNumber, @PathVariable Integer secondNumber)
	{
	return calculatorService.performsubtraction(firstNumber,secondNumber);
	}
	
	@GetMapping(value = "/division/{firstNumber}/{secondNumber}")
	public int performDivision(@PathVariable Integer firstNumber, @PathVariable Integer secondNumber)
	{
		int result = 0;
	try {
		result = calculatorService.performDivision(firstNumber,secondNumber);
	} catch (CustomizedException e) {
		e.printStackTrace();
	}
	return result;
	}
	
	@GetMapping(value = "/multiplication/{firstNumber}/{secondNumber}")
	public int performMultiplication(@PathVariable Integer firstNumber, @PathVariable Integer secondNumber)
	{
	return calculatorService.performMultiplication(firstNumber,secondNumber);
	}

}