package com.interview.calculatorapp.exceptionhandler;

public class CustomizedException extends Throwable{

	private static final long serialVersionUID = 1L;

	public CustomizedException(String...message){
		super();
		}
	}
