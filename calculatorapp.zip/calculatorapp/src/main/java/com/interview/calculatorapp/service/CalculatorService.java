package com.interview.calculatorapp.service;

import org.springframework.stereotype.Service;

import com.interview.calculatorapp.exceptionhandler.CustomizedException;

@Service
public class CalculatorService {

	public int performAddition(Integer firstNumber, Integer secondNumber) {
		
		return firstNumber+secondNumber;
		
	}

	public int performsubtraction(Integer firstNumber, Integer secondNumber) { 
		return firstNumber-secondNumber;
	}

	public int performDivision(Integer firstNumber, Integer secondNumber) throws CustomizedException {
		int result = 0;
		try {
			 result = firstNumber/secondNumber;
		} catch (Exception e) {
			throw new CustomizedException("division by zero not supported");
		}
		 return result;
	}

	public int performMultiplication(Integer firstNumber, Integer secondNumber) {
		return firstNumber*secondNumber;
	}
}
