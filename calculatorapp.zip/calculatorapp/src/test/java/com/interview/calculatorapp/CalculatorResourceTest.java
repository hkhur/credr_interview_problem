package com.interview.calculatorapp;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.interview.calculatorapp.exceptionhandler.CustomizedException;
import com.interview.calculatorapp.service.CalculatorService;

public class CalculatorResourceTest {
	
    CalculatorService calcService = new CalculatorService();	
	 
    @Test
	 public void testOerations() throws CustomizedException {
		
    	int addition = calcService.performAddition(2, 3);
		
	    int division = calcService.performDivision(2, 3);
	    
	    int subtract = calcService.performsubtraction(2, 3);
	   
	    int multilplication = calcService.performMultiplication(2, 3);
	    
	    assertEquals(addition,5);
	    
	    assertEquals(division,0);
	    
	    assertEquals(multilplication,6);
	    
	    assertEquals(subtract,-1);
	    
    }
	}
